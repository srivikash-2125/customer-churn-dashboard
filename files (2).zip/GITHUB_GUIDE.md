# 🚀 How to Post This Project on GitHub (Beginner Guide)

Follow these steps **exactly** — takes about 10 minutes.

---

## Part 1 — Run the project on your computer

### Step 1: Install Python
- Go to https://www.python.org/downloads/
- Download Python 3.10 or newer
- During install, **check "Add Python to PATH"** ✅

### Step 2: Download the dataset
- Go to https://www.kaggle.com/datasets/blastchar/telco-customer-churn
- Sign up for free Kaggle account if you don't have one
- Click **Download** button
- Extract the zip file
- Copy `WA_Fn-UseC_-Telco-Customer-Churn.csv` into the `data/` folder

### Step 3: Open Terminal (Command Prompt)
- **Windows**: Press `Win + R`, type `cmd`, press Enter
- **Mac**: Press `Cmd + Space`, type `Terminal`, press Enter

### Step 4: Navigate to the project folder
```bash
cd Downloads/customer-churn-prediction
```
(Change the path to wherever you saved the folder)

### Step 5: Install libraries
```bash
pip install -r requirements.txt
```
Wait for it to finish (2–3 minutes).

### Step 6: Run the analysis
```bash
python churn_analysis.py
```
You will see output printed in the terminal and charts saved to the `outputs/` folder.

### Step 7: Launch the dashboard
```bash
streamlit run app.py
```
A browser window opens at http://localhost:8501 — this is your live dashboard! 🎉

---

## Part 2 — Post on GitHub

### Step 1: Create a GitHub account
- Go to https://github.com
- Click **Sign up** — it's free

### Step 2: Create a new repository
- Click the **+** button (top right) → **New repository**
- Repository name: `customer-churn-prediction`
- Description: `End-to-end customer churn prediction using Python, Random Forest & Streamlit`
- Set to **Public**
- Check **Add a README file** — NO (we have our own)
- Click **Create repository**

### Step 3: Upload your files
On the new repository page:
- Click **uploading an existing file** (link in the middle of the page)
- Drag and drop these files:
  ```
  README.md
  churn_analysis.py
  app.py
  requirements.txt
  .gitignore
  GITHUB_GUIDE.md
  ```
- **DO NOT upload** the `data/` folder (dataset is too large)
- **DO NOT upload** the `outputs/` folder
- Scroll down → Click **Commit changes**

### Step 4: Add screenshots (optional but impressive)
- Take screenshots of your charts and dashboard
- Go to your repository → Click **Add file** → **Upload files**
- Upload your screenshots
- Mention them in README.md

### Step 5: Copy your GitHub link
Your project is now live at:
`https://github.com/YOUR-USERNAME/customer-churn-prediction`

---

## Part 3 — Add to Your Resume

### Resume line:
```
Customer Churn Prediction | Python, Random Forest, Streamlit, Scikit-learn
- Built end-to-end ML pipeline predicting customer churn with 82% accuracy (ROC-AUC: 0.87)
- Identified $X revenue at risk monthly; modeled ROI of targeted retention campaigns
- Deployed interactive dashboard using Streamlit; published on GitHub
GitHub: https://github.com/YOUR-USERNAME/customer-churn-prediction
```

### LinkedIn post idea:
```
🎯 Just completed my Customer Churn Prediction project!

✅ Analyzed 7,000+ telecom customers
✅ Random Forest model with 82% accuracy
✅ Built an interactive Streamlit dashboard
✅ Quantified monthly revenue at risk from churn

Tech: Python | Pandas | Scikit-learn | Streamlit | Plotly

Check it out: [GitHub link]

#DataAnalytics #Python #MachineLearning #DataScience
```

---

## 🎉 You're done!

You now have a complete, professional data analytics project on GitHub.
This project demonstrates:
- Data cleaning & EDA
- Machine learning modeling
- Business ROI thinking
- Dashboard development
- Version control (GitHub)
