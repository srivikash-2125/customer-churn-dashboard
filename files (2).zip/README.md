# 📉 Customer Churn Prediction — End-to-End Data Analytics Project

> Predict which customers are likely to cancel their subscription — and quantify the revenue at risk.

---

## 🎯 Business Problem

A telecom company loses revenue every time a customer leaves (churns).  
This project answers two critical questions:
- **Who is likely to churn next month?**
- **How much revenue will be lost if we don't act?**

By identifying at-risk customers early, the business can offer targeted retention deals — saving money before it's lost.

---

## 📁 Project Structure

```
customer-churn-prediction/
│
├── data/
│   └── WA_Fn-UseC_-Telco-Customer-Churn.csv   ← Download from Kaggle (link below)
│
├── outputs/
│   └── (charts and model files saved here automatically)
│
├── churn_analysis.py      ← Step 1: Full EDA + ML model + business insight
├── app.py                 ← Step 2: Interactive Streamlit dashboard
├── requirements.txt       ← All Python libraries needed
├── .gitignore             ← Files to exclude from GitHub
└── README.md              ← This file
```

---

## 📦 Dataset

**Telco Customer Churn** — Free on Kaggle  
🔗 https://www.kaggle.com/datasets/blastchar/telco-customer-churn

**Download steps:**
1. Click the link above
2. Click **Download** (you need a free Kaggle account)
3. Extract the CSV file
4. Place it inside the `data/` folder

---

## 🛠️ Setup Instructions (Step by Step)

### Step 1 — Install Python
Download Python 3.10+ from https://www.python.org/downloads/

### Step 2 — Open Terminal / Command Prompt
Navigate to the project folder:
```bash
cd customer-churn-prediction
```

### Step 3 — Install required libraries
```bash
pip install -r requirements.txt
```

### Step 4 — Run the analysis script
```bash
python churn_analysis.py
```
This will:
- Clean and explore the data
- Train a Random Forest model
- Print accuracy, precision, recall
- Save charts to the `outputs/` folder
- Print business ROI summary

### Step 5 — Launch the interactive dashboard
```bash
streamlit run app.py
```
Opens a live web dashboard at http://localhost:8501

---

## 📊 What This Project Covers

| Area | Details |
|------|---------|
| Data Cleaning | Handle missing values, fix data types |
| EDA | Churn rate by contract type, tenure, charges |
| Feature Engineering | Encode categorical variables, scale numerics |
| ML Models | Logistic Regression, Random Forest |
| Model Evaluation | Accuracy, Confusion Matrix, ROC-AUC, Feature Importance |
| Business Insight | Revenue at risk, cost of churn per segment |
| Dashboard | Interactive Streamlit app with live filters |

---

## 💡 Key Results (Sample)

- **Churn Rate:** ~26% of customers churn
- **Model Accuracy:** ~82% (Random Forest)
- **ROC-AUC Score:** ~0.87
- **Top churn drivers:** Month-to-month contracts, high monthly charges, low tenure
- **Revenue at risk:** Customers flagged as high-risk represent ~₹X in monthly revenue

---

## 🧰 Tech Stack

| Tool | Purpose |
|------|---------|
| Python 3.10+ | Core language |
| Pandas | Data manipulation |
| Matplotlib / Seaborn | Visualization |
| Scikit-learn | ML models |
| Streamlit | Dashboard |
| Joblib | Save/load model |

---

## 🚀 How to Post on GitHub

1. Create a free account at https://github.com
2. Click **New Repository** → name it `customer-churn-prediction`
3. Upload all files (drag and drop in browser)
4. Add a description: *"End-to-end churn prediction using Python, Random Forest & Streamlit"*
5. Share your GitHub link in your resume and LinkedIn

---

## 👤 Author

Your Name  
[LinkedIn] | [GitHub] | [Email]

---

## 📌 License

This project is open source under the MIT License.
