# ============================================================
#  Customer Churn Prediction — Full Analysis Script
#  Run this file first: python churn_analysis.py
# ============================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import seaborn as sns
import joblib
import os
import warnings
warnings.filterwarnings("ignore")

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, classification_report,
    confusion_matrix, roc_auc_score, roc_curve
)

# ── Paths ──────────────────────────────────────────────────
DATA_PATH    = "data/WA_Fn-UseC_-Telco-Customer-Churn.csv"
OUTPUTS_DIR  = "outputs"
os.makedirs(OUTPUTS_DIR, exist_ok=True)

# ── Plot style ─────────────────────────────────────────────
sns.set_theme(style="whitegrid", palette="muted")
plt.rcParams["figure.dpi"] = 130

# ===========================================================
#  STEP 1 — LOAD DATA
# ===========================================================
print("\n" + "="*55)
print("  STEP 1 — Loading Data")
print("="*55)

df = pd.read_csv(DATA_PATH)
print(f"  Rows: {df.shape[0]:,}  |  Columns: {df.shape[1]}")
print(f"  Columns: {list(df.columns)}")


# ===========================================================
#  STEP 2 — DATA CLEANING
# ===========================================================
print("\n" + "="*55)
print("  STEP 2 — Cleaning Data")
print("="*55)

# TotalCharges has spaces — convert to numeric
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")

# Fill the 11 missing TotalCharges rows (new customers, tenure=0)
df["TotalCharges"].fillna(0, inplace=True)

# Drop customerID — not useful for modeling
df.drop(columns=["customerID"], inplace=True)

# Convert Churn to binary  (Yes=1, No=0)
df["Churn"] = df["Churn"].map({"Yes": 1, "No": 0})

print(f"  Missing values after cleaning: {df.isnull().sum().sum()}")
print(f"  Churn rate: {df['Churn'].mean()*100:.1f}%")


# ===========================================================
#  STEP 3 — EXPLORATORY DATA ANALYSIS (EDA)
# ===========================================================
print("\n" + "="*55)
print("  STEP 3 — Exploratory Data Analysis")
print("="*55)

# ── Chart 1: Overall Churn Distribution ───────────────────
fig, ax = plt.subplots(figsize=(5, 4))
counts = df["Churn"].value_counts()
colors = ["#4E79A7", "#E15759"]
bars = ax.bar(["Retained", "Churned"], counts.values, color=colors, width=0.5, edgecolor="white")
for bar, val in zip(bars, counts.values):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 40,
            f"{val:,}\n({val/len(df)*100:.1f}%)", ha="center", va="bottom", fontsize=11)
ax.set_title("Customer Churn Distribution", fontsize=13, fontweight="bold", pad=12)
ax.set_ylabel("Number of Customers")
ax.set_ylim(0, counts.max() * 1.18)
sns.despine()
plt.tight_layout()
plt.savefig(f"{OUTPUTS_DIR}/01_churn_distribution.png")
plt.close()
print("  ✓ Saved: 01_churn_distribution.png")

# ── Chart 2: Churn by Contract Type ───────────────────────
fig, ax = plt.subplots(figsize=(7, 4))
contract_churn = df.groupby("Contract")["Churn"].mean().sort_values(ascending=False) * 100
bars = ax.barh(contract_churn.index, contract_churn.values,
               color=["#E15759", "#F28E2B", "#4E79A7"], edgecolor="white")
for bar, val in zip(bars, contract_churn.values):
    ax.text(val + 0.5, bar.get_y() + bar.get_height()/2,
            f"{val:.1f}%", va="center", fontsize=11)
ax.set_title("Churn Rate by Contract Type", fontsize=13, fontweight="bold", pad=12)
ax.set_xlabel("Churn Rate (%)")
ax.set_xlim(0, contract_churn.max() * 1.2)
sns.despine()
plt.tight_layout()
plt.savefig(f"{OUTPUTS_DIR}/02_churn_by_contract.png")
plt.close()
print("  ✓ Saved: 02_churn_by_contract.png")

# ── Chart 3: Churn by Tenure (binned) ────────────────────
df["tenure_group"] = pd.cut(df["tenure"],
    bins=[0, 12, 24, 48, 72],
    labels=["0–12 mo", "13–24 mo", "25–48 mo", "49–72 mo"])
fig, ax = plt.subplots(figsize=(7, 4))
tg = df.groupby("tenure_group")["Churn"].mean() * 100
bars = ax.bar(tg.index.astype(str), tg.values,
              color=["#E15759", "#F28E2B", "#59A14F", "#4E79A7"], edgecolor="white")
for bar, val in zip(bars, tg.values):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3,
            f"{val:.1f}%", ha="center", fontsize=11)
ax.set_title("Churn Rate by Tenure Group", fontsize=13, fontweight="bold", pad=12)
ax.set_ylabel("Churn Rate (%)")
ax.set_ylim(0, tg.max() * 1.2)
sns.despine()
plt.tight_layout()
plt.savefig(f"{OUTPUTS_DIR}/03_churn_by_tenure.png")
plt.close()
print("  ✓ Saved: 03_churn_by_tenure.png")

# ── Chart 4: Monthly Charges — Churned vs Retained ────────
fig, ax = plt.subplots(figsize=(7, 4))
df[df["Churn"] == 0]["MonthlyCharges"].plot(kind="kde", ax=ax,
    label="Retained", color="#4E79A7", linewidth=2)
df[df["Churn"] == 1]["MonthlyCharges"].plot(kind="kde", ax=ax,
    label="Churned", color="#E15759", linewidth=2, linestyle="--")
ax.set_title("Monthly Charges Distribution", fontsize=13, fontweight="bold", pad=12)
ax.set_xlabel("Monthly Charges ($)")
ax.legend()
sns.despine()
plt.tight_layout()
plt.savefig(f"{OUTPUTS_DIR}/04_monthly_charges.png")
plt.close()
print("  ✓ Saved: 04_monthly_charges.png")


# ===========================================================
#  STEP 4 — FEATURE ENGINEERING
# ===========================================================
print("\n" + "="*55)
print("  STEP 4 — Feature Engineering")
print("="*55)

df_model = df.drop(columns=["tenure_group"])

# Encode all categorical columns
le = LabelEncoder()
cat_cols = df_model.select_dtypes(include=["object"]).columns
for col in cat_cols:
    df_model[col] = le.fit_transform(df_model[col])

# Separate features (X) and target (y)
X = df_model.drop(columns=["Churn"])
y = df_model["Churn"]

# Train / Test split  (80% train, 20% test)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)

# Scale numeric features
scaler = StandardScaler()
X_train_sc = scaler.fit_transform(X_train)
X_test_sc  = scaler.transform(X_test)

print(f"  Training samples : {X_train.shape[0]:,}")
print(f"  Testing  samples : {X_test.shape[0]:,}")
print(f"  Features used    : {X_train.shape[1]}")


# ===========================================================
#  STEP 5 — MODEL TRAINING
# ===========================================================
print("\n" + "="*55)
print("  STEP 5 — Training Models")
print("="*55)

# ── Model A: Logistic Regression ──────────────────────────
lr = LogisticRegression(max_iter=1000, random_state=42)
lr.fit(X_train_sc, y_train)
lr_preds = lr.predict(X_test_sc)
lr_proba = lr.predict_proba(X_test_sc)[:, 1]

# ── Model B: Random Forest ────────────────────────────────
rf = RandomForestClassifier(n_estimators=200, max_depth=10,
                             random_state=42, n_jobs=-1)
rf.fit(X_train, y_train)
rf_preds = rf.predict(X_test)
rf_proba = rf.predict_proba(X_test)[:, 1]


# ===========================================================
#  STEP 6 — MODEL EVALUATION
# ===========================================================
print("\n" + "="*55)
print("  STEP 6 — Model Evaluation")
print("="*55)

for name, preds, proba in [
    ("Logistic Regression", lr_preds, lr_proba),
    ("Random Forest",       rf_preds, rf_proba),
]:
    acc = accuracy_score(y_test, preds)
    auc = roc_auc_score(y_test, proba)
    print(f"\n  ── {name} ──")
    print(f"  Accuracy  : {acc*100:.2f}%")
    print(f"  ROC-AUC   : {auc:.4f}")
    print(classification_report(y_test, preds,
          target_names=["Retained", "Churned"], digits=3))

# ── Chart 5: Confusion Matrix (Random Forest) ────────────
cm = confusion_matrix(y_test, rf_preds)
fig, ax = plt.subplots(figsize=(5, 4))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
            xticklabels=["Retained", "Churned"],
            yticklabels=["Retained", "Churned"], ax=ax)
ax.set_title("Confusion Matrix — Random Forest", fontsize=13, fontweight="bold", pad=12)
ax.set_ylabel("Actual")
ax.set_xlabel("Predicted")
plt.tight_layout()
plt.savefig(f"{OUTPUTS_DIR}/05_confusion_matrix.png")
plt.close()
print("  ✓ Saved: 05_confusion_matrix.png")

# ── Chart 6: ROC Curve ────────────────────────────────────
fig, ax = plt.subplots(figsize=(6, 5))
for name, proba, color in [
    ("Logistic Regression", lr_proba, "#4E79A7"),
    ("Random Forest",       rf_proba, "#E15759"),
]:
    fpr, tpr, _ = roc_curve(y_test, proba)
    auc = roc_auc_score(y_test, proba)
    ax.plot(fpr, tpr, label=f"{name}  (AUC={auc:.3f})",
            linewidth=2, color=color)
ax.plot([0,1],[0,1], "k--", linewidth=1)
ax.set_title("ROC Curve Comparison", fontsize=13, fontweight="bold", pad=12)
ax.set_xlabel("False Positive Rate")
ax.set_ylabel("True Positive Rate")
ax.legend()
sns.despine()
plt.tight_layout()
plt.savefig(f"{OUTPUTS_DIR}/06_roc_curve.png")
plt.close()
print("  ✓ Saved: 06_roc_curve.png")

# ── Chart 7: Feature Importance ──────────────────────────
feat_imp = pd.Series(rf.feature_importances_, index=X.columns)
feat_imp = feat_imp.sort_values(ascending=True).tail(10)
fig, ax = plt.subplots(figsize=(7, 5))
feat_imp.plot(kind="barh", ax=ax, color="#4E79A7", edgecolor="white")
ax.set_title("Top 10 Feature Importances (Random Forest)",
             fontsize=13, fontweight="bold", pad=12)
ax.set_xlabel("Importance Score")
sns.despine()
plt.tight_layout()
plt.savefig(f"{OUTPUTS_DIR}/07_feature_importance.png")
plt.close()
print("  ✓ Saved: 07_feature_importance.png")


# ===========================================================
#  STEP 7 — BUSINESS INSIGHT (ROI Calculation)
# ===========================================================
print("\n" + "="*55)
print("  STEP 7 — Business Insight / ROI")
print("="*55)

# Add churn probability to original df
df["churn_probability"] = rf.predict_proba(X[rf.feature_names_in_])[:, 1]
df["risk_tier"] = pd.cut(df["churn_probability"],
    bins=[0, 0.3, 0.6, 1.0],
    labels=["Low Risk", "Medium Risk", "High Risk"])

# Revenue at risk calculation
avg_monthly_charge = df["MonthlyCharges"].mean()
high_risk_customers = (df["risk_tier"] == "High Risk").sum()
revenue_at_risk = high_risk_customers * avg_monthly_charge

print(f"\n  Total customers          : {len(df):,}")
print(f"  High-risk customers      : {high_risk_customers:,}")
print(f"  Avg monthly charge       : ${avg_monthly_charge:.2f}")
print(f"  Monthly revenue at risk  : ${revenue_at_risk:,.0f}")
print(f"  Annual revenue at risk   : ${revenue_at_risk*12:,.0f}")
print(f"\n  ★  Retaining just 20% of high-risk customers")
print(f"     saves ${revenue_at_risk*0.20:,.0f}/month  (${revenue_at_risk*0.20*12:,.0f}/year)")

# ── Chart 8: Risk Tier Breakdown ──────────────────────────
fig, ax = plt.subplots(figsize=(6, 4))
risk_counts = df["risk_tier"].value_counts()
colors_risk = {"Low Risk": "#59A14F", "Medium Risk": "#F28E2B", "High Risk": "#E15759"}
bars = ax.bar(risk_counts.index, risk_counts.values,
              color=[colors_risk[r] for r in risk_counts.index],
              edgecolor="white", width=0.5)
for bar, val in zip(bars, risk_counts.values):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 20,
            f"{val:,}", ha="center", fontsize=11)
ax.set_title("Customer Risk Tier Distribution", fontsize=13, fontweight="bold", pad=12)
ax.set_ylabel("Number of Customers")
sns.despine()
plt.tight_layout()
plt.savefig(f"{OUTPUTS_DIR}/08_risk_tiers.png")
plt.close()
print("\n  ✓ Saved: 08_risk_tiers.png")


# ===========================================================
#  STEP 8 — SAVE MODEL & SCALER
# ===========================================================
print("\n" + "="*55)
print("  STEP 8 — Saving Model")
print("="*55)

joblib.dump(rf,     f"{OUTPUTS_DIR}/churn_model.pkl")
joblib.dump(scaler, f"{OUTPUTS_DIR}/scaler.pkl")
df.to_csv(f"{OUTPUTS_DIR}/predictions.csv", index=False)

print("  ✓ Saved: outputs/churn_model.pkl")
print("  ✓ Saved: outputs/scaler.pkl")
print("  ✓ Saved: outputs/predictions.csv  (with risk scores)")

print("\n" + "="*55)
print("  ✅  Analysis complete! Check the outputs/ folder.")
print("  ▶   Next: run  streamlit run app.py  for dashboard")
print("="*55 + "\n")
