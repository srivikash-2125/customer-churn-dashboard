# ============================================================
#  Customer Churn Dashboard — Streamlit App
#  Run: streamlit run app.py
# ============================================================

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import joblib
import os

# ── Page config ────────────────────────────────────────────
st.set_page_config(
    page_title="Customer Churn Dashboard",
    page_icon="📉",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ── Custom CSS ─────────────────────────────────────────────
st.markdown("""
<style>
    .metric-card {
        background: #f8f9fa;
        border-left: 4px solid #4E79A7;
        padding: 16px 20px;
        border-radius: 8px;
        margin-bottom: 12px;
    }
    .risk-high   { border-left-color: #E15759 !important; }
    .risk-medium { border-left-color: #F28E2B !important; }
    .risk-low    { border-left-color: #59A14F !important; }
    h1 { color: #1f2937; }
</style>
""", unsafe_allow_html=True)

# ── Load data ──────────────────────────────────────────────
@st.cache_data
def load_data():
    path = "outputs/predictions.csv"
    if not os.path.exists(path):
        st.error("⚠️ Run `python churn_analysis.py` first to generate predictions.csv")
        st.stop()
    return pd.read_csv(path)

df = load_data()

# ── Sidebar filters ────────────────────────────────────────
st.sidebar.image("https://img.icons8.com/fluency/96/combo-chart.png", width=60)
st.sidebar.title("Filters")

contract_filter = st.sidebar.multiselect(
    "Contract Type",
    options=df["Contract"].unique() if "Contract" in df.columns else [],
    default=df["Contract"].unique() if "Contract" in df.columns else []
)

risk_filter = st.sidebar.multiselect(
    "Risk Tier",
    options=["High Risk", "Medium Risk", "Low Risk"],
    default=["High Risk", "Medium Risk", "Low Risk"]
)

tenure_range = st.sidebar.slider(
    "Tenure (months)",
    min_value=int(df["tenure"].min()),
    max_value=int(df["tenure"].max()),
    value=(int(df["tenure"].min()), int(df["tenure"].max()))
)

# ── Apply filters ──────────────────────────────────────────
mask = (
    df["risk_tier"].isin(risk_filter) &
    df["tenure"].between(*tenure_range)
)
if "Contract" in df.columns and len(contract_filter) > 0:
    mask = mask & df["Contract"].isin(contract_filter)

filtered = df[mask]

# ── Header ─────────────────────────────────────────────────
st.title("📉 Customer Churn Prediction Dashboard")
st.caption("Powered by Random Forest · Telco Dataset · Built with Python & Streamlit")
st.divider()

# ── KPI Row ────────────────────────────────────────────────
col1, col2, col3, col4 = st.columns(4)

total_customers  = len(filtered)
churned          = filtered["Churn"].sum() if "Churn" in filtered.columns else 0
churn_rate       = churned / total_customers * 100 if total_customers > 0 else 0
high_risk_count  = (filtered["risk_tier"] == "High Risk").sum()
avg_monthly      = filtered["MonthlyCharges"].mean() if "MonthlyCharges" in filtered.columns else 0
revenue_at_risk  = high_risk_count * avg_monthly

col1.metric("👥 Total Customers",    f"{total_customers:,}")
col2.metric("⚠️ Churn Rate",         f"{churn_rate:.1f}%",     delta=f"{churn_rate-26:.1f}% vs avg", delta_color="inverse")
col3.metric("🚨 High-Risk Customers", f"{high_risk_count:,}")
col4.metric("💰 Monthly Revenue at Risk", f"${revenue_at_risk:,.0f}")

st.divider()

# ── Charts Row 1 ───────────────────────────────────────────
col_a, col_b = st.columns(2)

with col_a:
    st.subheader("Risk Tier Breakdown")
    risk_counts = filtered["risk_tier"].value_counts().reset_index()
    risk_counts.columns = ["Risk Tier", "Count"]
    color_map = {"High Risk": "#E15759", "Medium Risk": "#F28E2B", "Low Risk": "#59A14F"}
    fig = px.bar(risk_counts, x="Risk Tier", y="Count",
                 color="Risk Tier", color_discrete_map=color_map,
                 text="Count", height=350)
    fig.update_traces(textposition="outside")
    fig.update_layout(showlegend=False, plot_bgcolor="white",
                      yaxis_title="Number of Customers")
    st.plotly_chart(fig, use_container_width=True)

with col_b:
    st.subheader("Churn Probability Distribution")
    fig = px.histogram(filtered, x="churn_probability", nbins=30,
                       color_discrete_sequence=["#4E79A7"],
                       labels={"churn_probability": "Churn Probability"},
                       height=350)
    fig.add_vline(x=0.5, line_dash="dash", line_color="#E15759",
                  annotation_text="Decision threshold (0.5)")
    fig.update_layout(plot_bgcolor="white")
    st.plotly_chart(fig, use_container_width=True)

# ── Charts Row 2 ───────────────────────────────────────────
col_c, col_d = st.columns(2)

with col_c:
    if "Contract" in filtered.columns:
        st.subheader("Churn Rate by Contract Type")
        ct = filtered.groupby("Contract")["churn_probability"].mean().reset_index()
        ct.columns = ["Contract", "Avg Churn Probability"]
        ct["Avg Churn Probability"] = (ct["Avg Churn Probability"] * 100).round(1)
        fig = px.bar(ct, x="Contract", y="Avg Churn Probability",
                     color="Avg Churn Probability",
                     color_continuous_scale=["#59A14F", "#F28E2B", "#E15759"],
                     text="Avg Churn Probability", height=350)
        fig.update_traces(texttemplate="%{text:.1f}%", textposition="outside")
        fig.update_layout(plot_bgcolor="white", coloraxis_showscale=False)
        st.plotly_chart(fig, use_container_width=True)

with col_d:
    st.subheader("Monthly Charges vs Churn Probability")
    sample = filtered.sample(min(500, len(filtered)), random_state=42)
    fig = px.scatter(sample, x="MonthlyCharges", y="churn_probability",
                     color="risk_tier",
                     color_discrete_map={"High Risk":"#E15759",
                                          "Medium Risk":"#F28E2B",
                                          "Low Risk":"#59A14F"},
                     opacity=0.6, height=350,
                     labels={"churn_probability": "Churn Probability",
                             "MonthlyCharges": "Monthly Charges ($)"})
    fig.update_layout(plot_bgcolor="white")
    st.plotly_chart(fig, use_container_width=True)

# ── High-Risk Customer Table ────────────────────────────────
st.divider()
st.subheader("🚨 High-Risk Customers — Action Required")
st.caption("These customers have >60% probability of churning. Prioritize retention offers.")

high_risk_df = filtered[filtered["risk_tier"] == "High Risk"].copy()
high_risk_df["churn_probability"] = (high_risk_df["churn_probability"] * 100).round(1)

display_cols = [c for c in ["tenure", "Contract", "MonthlyCharges",
                              "TotalCharges", "churn_probability", "risk_tier"]
                if c in high_risk_df.columns]

st.dataframe(
    high_risk_df[display_cols]
      .sort_values("churn_probability", ascending=False)
      .head(50)
      .rename(columns={"churn_probability": "Churn Probability (%)"}),
    use_container_width=True,
    hide_index=True
)

# ── ROI Estimator ───────────────────────────────────────────
st.divider()
st.subheader("💡 Retention ROI Estimator")
st.caption("How much can we save by targeting high-risk customers with retention offers?")

col_e, col_f, col_g = st.columns(3)

with col_e:
    retention_rate = st.slider("% of high-risk customers retained", 5, 50, 20)
with col_f:
    offer_cost = st.slider("Retention offer cost per customer ($)", 0, 50, 10)
with col_g:
    st.write("")  # spacer

customers_saved   = int(high_risk_count * retention_rate / 100)
revenue_saved     = customers_saved * avg_monthly
campaign_cost     = high_risk_count * offer_cost
net_benefit       = revenue_saved - campaign_cost

col_h, col_i, col_j = st.columns(3)
col_h.metric("Customers Saved",   f"{customers_saved:,}")
col_i.metric("Monthly Revenue Saved", f"${revenue_saved:,.0f}")
col_j.metric("Net Monthly Benefit",   f"${net_benefit:,.0f}",
             delta="positive" if net_benefit > 0 else "negative")

st.markdown(f"""
> **Annual net benefit: `${net_benefit*12:,.0f}`**  
> By spending **${campaign_cost:,.0f}/month** on retention offers, we recover **${revenue_saved:,.0f}/month** in would-be lost revenue.
""")

st.divider()
st.caption("Project by: [Your Name] | Dataset: Telco Customer Churn (Kaggle) | Model: Random Forest")
